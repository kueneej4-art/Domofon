#!/usr/bin/env python3
"""
API личного кабинета «Домофон Сервис» поверх app.db (результат export77.py).
Запуск:  python3 server.py app.db [--port 8080]       (провайдер оплаты: PAY_PROVIDER=mock|yookassa|robokassa|sber, см. payments.py)

POST /api/auth          {"account":"00144159","code":"AB7K2QXM"} -> {"token": "..."}
GET  /api/account       адрес, долг, тариф, маскированное ФИО
GET  /api/history       последние операции
POST /api/pay           {"amount":300,"return_url","receipt_contact"} -> {"order","url"}  (url = страница ЮKassa; null в режиме mock)
                        receipt_contact — телефон или e-mail для чека (54-ФЗ); запоминается за лицевым счётом
POST /api/yookassa/notify                              уведомления ЮKassa (адрес указать в личном кабинете)
POST /api/robokassa/result                             Result URL Робокассы (подпись паролем №2, ответ OK<InvId>)
GET|POST /api/sber/notify                              уведомления (callback) интернет-эквайринга Сбербанка
POST /api/pay/confirm   {"order":"..."}               -> {"paid": true}
GET  /api/autopay                                      -> настройки автоплатежа
POST /api/autopay       {"action":"bind","day","max_amount","return_url","receipt_contact"} -> {"order","url"}
                        первый платёж (долг или аванс) с сохранением карты в ЮKassa
                        {"action":"confirm","order"}   -> карта сохранена, автоплатёж включён
                        {"action":"settings","day":5,"max_amount":1000[,"receipt_contact"]}
                        {"action":"off"}
POST /api/lead          {"name","phone","street","house","entrance","flat","kind","comment"} — заявка на подключение (без входа)
GET  /api/ping
GET  /api/registry/list         заголовок X-Registry-Key: <REGISTRY_KEY>  -> реестры для 1С за 60 дней
GET  /api/registry/file?name=…  тот же заголовок -> сам файл (забирает скрипт на сервере 1С)
Защита: 5 неверных кодов подряд -> блокировка на 30 минут; ФИО и телефон отдаются маскированными.
"""
import os, sys, re, json, sqlite3, secrets, time, argparse, datetime, urllib.parse
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import payments as P
import leads as L

TOKENS, FAILS = {}, {}
TTL, MAX_FAILS, LOCK = 30 * 24 * 3600, 5, 30 * 60


def mask_fio(s):
    p = s.replace('.', ' ').split()
    if not p: return ''
    return p[0][0] + '*' * (len(p[0]) - 1) + (' ' + ' '.join(x[0] + '.' for x in p[1:]) if len(p) > 1 else '')


def mask_phone(s):
    d = ''.join(c for c in s if c.isdigit())
    return f'+7 *** ***-**-{d[-2:]}' if len(d) >= 10 else ''


def next_charge(day):
    t = datetime.date.today()
    d = t.replace(day=day)
    if d <= t: d = (t.replace(day=1) + datetime.timedelta(days=32)).replace(day=day)
    return d.isoformat()


class H(BaseHTTPRequestHandler):
    db = None; prov = None

    def send(self, code, obj):
        b = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Headers', 'Authorization, Content-Type')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)

    def do_OPTIONS(self): self.send(204, {})

    def send_text(self, code, text):
        b = text.encode()
        self.send_response(code)
        self.send_header('Content-Type', 'text/plain; charset=utf-8')
        self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)

    def form(self):
        """Параметры уведомления: из строки запроса и (для POST) из тела в формате формы или JSON."""
        q = dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(self.path).query))
        if self.command == 'POST':
            raw = self.rfile.read(int(self.headers.get('Content-Length', 0) or 0)).decode('utf-8', 'replace')
            if raw.lstrip().startswith('{'):
                try: q.update({k: str(v) for k, v in json.loads(raw).items()})
                except ValueError: pass
            else:
                q.update(dict(urllib.parse.parse_qsl(raw)))
        return q

    def provider_notify(self, path):
        """Уведомления Робокассы и Сбера. Телу не доверяем: только повод перепроверить платёж у провайдера."""
        f = self.form()
        if path == '/api/robokassa/result':
            if self.prov.name != 'robokassa': return self.send_text(404, 'not robokassa')
            inv = f.get('InvId', '')
            if not self.prov.check_result(f.get('OutSum', ''), inv, f.get('SignatureValue', '')):
                return self.send_text(400, 'bad sign')
            order = inv
        else:
            if self.prov.name != 'sber': return self.send(404, {'error': 'not_sber'})
            order = f.get('mdOrder', '')
        row = self.db.execute('SELECT id FROM payments WHERE provider_order=?', (order,)).fetchone()
        if row:
            try: self.sync(row[0])
            except Exception: return self.send_text(500, 'retry')          # провайдер повторит уведомление
        if path == '/api/robokassa/result': return self.send_text(200, 'OK' + order)
        return self.send(200, {})

    def who(self):
        t = self.headers.get('Authorization', '').removeprefix('Bearer ').strip()
        a = TOKENS.get(t)
        return a[0] if a and a[1] > time.time() else None

    def body(self):
        try: return json.loads(self.rfile.read(int(self.headers.get('Content-Length', 0))) or b'{}')
        except ValueError: return None

    def debt(self, acc):
        r = self.db.execute('SELECT debt FROM accounts WHERE account=?', (acc,)).fetchone()
        return round((r[0] if r else 0) - P.unexported_paid(self.db, acc), 2)

    def autopay_state(self, acc):
        r = self.db.execute('SELECT enabled, day, max_amount, card_mask FROM autopay WHERE account=?', (acc,)).fetchone()
        if not r: return {'enabled': False, 'day': 5, 'max_amount': 1000, 'card_mask': None, 'next_date': None, 'provider': self.prov.name}
        return {'enabled': bool(r[0]), 'day': r[1], 'max_amount': r[2], 'card_mask': r[3],
                'next_date': next_charge(r[1]) if r[0] else None, 'provider': self.prov.name}

    # ---------------- платежи ----------------
    def contact(self, acc, body):
        """Контакт для чека из запроса (и запомнить) или сохранённый. None — если прислан, но неверный."""
        raw = str(body.get('receipt_contact') or '').strip()
        if raw:
            c = P.norm_contact(raw)
            if not c: return None
            if c != P.get_contact(self.db, acc): P.set_contact(self.db, acc, c)
            return c
        return P.get_contact(self.db, acc)

    def need_contact(self, c):
        return getattr(self.prov, 'receipt', False) and not c

    def return_url(self, body):
        u = str(body.get('return_url') or '')
        allowed = os.environ.get('RETURN_PREFIXES', 'https://kueneej4-art.github.io/,http://localhost').split(',')
        return u if any(u.startswith(x) for x in allowed if x) else allowed[0]

    def sync(self, pid):
        """Проверить платёж у провайдера и обновить payments / autopay. Возвращает статус."""
        row = self.db.execute('SELECT account, kind, status, provider_order FROM payments WHERE id=?', (pid,)).fetchone()
        if not row: return None
        acc, kind, st, order = row
        if st in ('paid', 'canceled'): return st
        r = self.prov.get_payment(order)
        if r['paid']:
            self.db.execute("UPDATE payments SET status='paid', paid=? WHERE id=?", (P.now(), pid))
            if kind == 'bind' and r['method_id']:
                self.db.execute('UPDATE autopay SET enabled=1, binding_id=?, card_mask=?, pending_order=NULL, updated=? WHERE account=?',
                                (r['method_id'], r['card_mask'], P.now(), acc))
            st = 'paid'
        elif r['final']:
            self.db.execute("UPDATE payments SET status='canceled' WHERE id=?", (pid,)); st = 'canceled'
        self.db.commit()
        return st

    # ---------------- POST ----------------
    def do_POST(self):
        path = self.path.split('?')[0]
        if path in ('/api/robokassa/result', '/api/sber/notify'): return self.provider_notify(path)
        body = self.body()
        if body is None: return self.send(400, {'error': 'bad_json'})
        if path == '/api/auth': return self.auth(body)
        if path == '/api/lead':                                  # заявка на подключение — без входа в кабинет
            code, resp = L.create(self.db, body, self.who())
            return self.send(code, resp)
        if path == '/api/yookassa/notify':                      # уведомление ЮKassa: только повод перепроверить платёж
            oid = ((body.get('object') or {}).get('id')) or ''
            row = self.db.execute('SELECT id FROM payments WHERE provider_order=?', (oid,)).fetchone()
            if row:
                try: self.sync(row[0])
                except Exception: return self.send(500, {'error': 'retry'})   # ЮKassa повторит
            return self.send(200, {})
        acc = self.who()
        if not acc: return self.send(401, {'error': 'unauthorized'})
        try:
            if path == '/api/pay':
                amount = round(float(body.get('amount', 0)), 2)
                if not 1 <= amount <= 50000: return self.send(400, {'error': 'bad_amount'})
                c = self.contact(acc, body)
                if c is None: return self.send(400, {'error': 'bad_receipt_contact'})
                if self.need_contact(c): return self.send(400, {'error': 'need_receipt_contact'})
                pid = P.new_id()
                r = self.prov.create_payment(acc, pid, amount, self.return_url(body), contact=c)
                self.db.execute('INSERT INTO payments(id, account, amount, kind, status, provider_order, created, paid, exported) VALUES (?,?,?,?,?,?,?,?,0)', (pid, acc, amount, 'app', 'new', r['order'], P.now(), None))
                self.db.commit()
                return self.send(200, {'order': pid, 'url': r['url']})
            if path == '/api/pay/confirm':
                pid = str(body.get('order', ''))
                if not self.db.execute('SELECT 1 FROM payments WHERE id=? AND account=?', (pid, acc)).fetchone():
                    return self.send(404, {'error': 'no_order'})
                st = self.sync(pid)
                return self.send(200, {'paid': st == 'paid', 'status': st, 'debt': self.debt(acc), 'autopay': self.autopay_state(acc)})
            if path == '/api/autopay':
                a = body.get('action')
                if a == 'bind':
                    day = int(body.get('day', 5)); mx = float(body.get('max_amount', 1000))
                    if not (1 <= day <= 28 and 50 <= mx <= 50000): return self.send(400, {'error': 'bad_settings'})
                    c = self.contact(acc, body)
                    if c is None: return self.send(400, {'error': 'bad_receipt_contact'})
                    if self.need_contact(c): return self.send(400, {'error': 'need_receipt_contact'})
                    # первый платёж с сохранением карты: текущий долг (до лимита) или аванс за месяц
                    tariff = (self.db.execute('SELECT tariff FROM accounts WHERE account=?', (acc,)).fetchone() or [None])[0] or 100
                    amount = round(min(self.debt(acc), mx), 2)
                    if amount < 1: amount = float(tariff)
                    pid = P.new_id()
                    r = self.prov.create_payment(acc, pid, amount, self.return_url(body), save=True,
                                                 description=f'Домофон, л/с {acc}, подключение автоплатежа', contact=c)
                    self.db.execute('INSERT INTO payments(id, account, amount, kind, status, provider_order, created, paid, exported) VALUES (?,?,?,?,?,?,?,?,0)', (pid, acc, amount, 'bind', 'new', r['order'], P.now(), None))
                    self.db.execute('INSERT INTO autopay(account, enabled, day, max_amount, pending_order, updated) VALUES (?,0,?,?,?,?) '
                                    'ON CONFLICT(account) DO UPDATE SET day=excluded.day, max_amount=excluded.max_amount, '
                                    'pending_order=excluded.pending_order, updated=excluded.updated', (acc, day, mx, pid, P.now()))
                    self.db.commit()
                    return self.send(200, {'order': pid, 'url': r['url'], 'amount': amount})
                if a == 'confirm':
                    row = self.db.execute('SELECT pending_order FROM autopay WHERE account=?', (acc,)).fetchone()
                    pid = str(body.get('order') or (row and row[0]) or '')
                    st = self.sync(pid) if pid else None
                    state = self.autopay_state(acc)
                    if not state['enabled']: return self.send(402, {'error': 'binding_failed', 'status': st})
                    return self.send(200, {**state, 'debt': self.debt(acc)})
                if a == 'settings':
                    day = int(body.get('day', 5)); mx = float(body.get('max_amount', 1000))
                    if not (1 <= day <= 28 and 50 <= mx <= 50000): return self.send(400, {'error': 'bad_settings'})
                    if self.contact(acc, body) is None: return self.send(400, {'error': 'bad_receipt_contact'})
                    self.db.execute('UPDATE autopay SET day=?, max_amount=?, updated=? WHERE account=?', (day, mx, P.now(), acc)); self.db.commit()
                    return self.send(200, self.autopay_state(acc))
                if a == 'off':
                    self.db.execute('UPDATE autopay SET enabled=0, binding_id=NULL, card_mask=NULL, updated=? WHERE account=?', (P.now(), acc)); self.db.commit()
                    return self.send(200, self.autopay_state(acc))
                return self.send(400, {'error': 'bad_action'})
        except Exception as e:                                   # ошибка платёжной системы — не роняем сервер
            return self.send(502, {'error': 'provider', 'detail': str(e)[:200]})
        self.send(404, {'error': 'not_found'})

    def auth(self, body):
        acc = str(body.get('account', '')).strip().zfill(8); code = str(body.get('code', '')).strip().upper()
        cnt, until = FAILS.get(acc, (0, 0))
        if until > time.time(): return self.send(429, {'error': 'locked', 'retry_after': int(until - time.time())})
        row = self.db.execute('SELECT code FROM access WHERE account=?', (acc,)).fetchone()
        if not row or not secrets.compare_digest(row[0], code):
            cnt += 1
            FAILS[acc] = (0, time.time() + LOCK) if cnt >= MAX_FAILS else (cnt, 0)
            return self.send(401, {'error': 'wrong_account_or_code', 'attempts_left': max(0, MAX_FAILS - cnt)})
        FAILS.pop(acc, None)
        tok = secrets.token_urlsafe(32); TOKENS[tok] = (acc, time.time() + TTL)
        self.send(200, {'token': tok})

    # ---------------- GET ----------------
    # ---------------- реестры для сервера 1С ----------------
    REG_NAME = re.compile(r'^((YOOKASSA|ROBOKASSA|SBER)_PAY_[A-Za-z0-9_]+\.CSV|ZAYAVKI_PODKLYUCHENIE\.csv)$')

    def registry(self, path):
        key = P.env('REGISTRY_KEY')
        given = self.headers.get('X-Registry-Key', '').strip()
        if len(key) < 24 or not secrets.compare_digest(given.encode(), key.encode()):
            time.sleep(1)                                        # притормозим перебор ключа
            return self.send(403, {'error': 'forbidden'})
        rdir = P.env('REGISTRY_DIR', '/opt/domofon-api/registry')
        if path == '/api/registry/list':
            out, cutoff = [], time.time() - 60 * 86400
            for n in sorted(os.listdir(rdir)) if os.path.isdir(rdir) else []:
                fp = os.path.join(rdir, n)
                if self.REG_NAME.match(n) and os.path.getmtime(fp) >= cutoff:
                    out.append({'name': n, 'size': os.path.getsize(fp), 'mtime': int(os.path.getmtime(fp))})
            return self.send(200, out)
        name = (urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query).get('name') or [''])[0]
        fp = os.path.join(rdir, name)
        if not self.REG_NAME.match(name) or not os.path.isfile(fp):
            return self.send(404, {'error': 'no_file'})
        with open(fp, 'rb') as f: b = f.read()
        self.send_response(200)
        self.send_header('Content-Type', 'application/octet-stream')
        self.send_header('Content-Disposition', f'attachment; filename="{name}"')
        self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)

    def do_GET(self):
        path = self.path.split('?')[0]
        if path in ('/api/registry/list', '/api/registry/file'): return self.registry(path)
        if path in ('/api/robokassa/result', '/api/sber/notify'): return self.provider_notify(path)
        if path == '/api/ping':
            asof = self.db.execute("SELECT value FROM meta WHERE key='asof'").fetchone()
            return self.send(200, {'ok': True, 'data_asof': asof and asof[0], 'pay_provider': self.prov.name})
        acc = self.who()
        if not acc: return self.send(401, {'error': 'unauthorized'})
        if path == '/api/account':
            r = self.db.execute('SELECT account,fio,address,phone,tariff,debt,last_pay_date,last_pay FROM accounts WHERE account=?', (acc,)).fetchone()
            d = self.debt(acc)
            return self.send(200, {'account': r[0], 'fio': mask_fio(r[1]), 'address': r[2], 'phone': mask_phone(r[3]),
                                   'tariff': r[4], 'debt': max(d, 0), 'prepaid': max(-d, 0),
                                   'last_payment': r[6] and {'date': r[6], 'amount': r[7]},
                                   'autopay': self.autopay_state(acc),
                                   'receipt_contact': P.get_contact(self.db, acc),
                                   'receipt_required': bool(getattr(self.prov, 'receipt', False))})
        if path == '/api/history':
            rows = self.db.execute('SELECT date,kind,amount FROM history WHERE account=? ORDER BY date DESC LIMIT 36', (acc,)).fetchall()
            app_pays = self.db.execute("SELECT replace(substr(paid,1,10),'-',''), kind, amount FROM payments WHERE account=? AND status='paid' ORDER BY paid DESC LIMIT 12", (acc,)).fetchall()
            out = [{'date': d, 'kind': 'Автоплатёж' if k == 'auto' else 'Оплата в приложении', 'amount': s, 'sign': '-'} for d, k, s in app_pays]
            out += [{'date': d, 'kind': k, 'amount': abs(s), 'sign': '+' if s > 0 else '-'} for d, k, s in rows]
            return self.send(200, sorted(out, key=lambda x: x['date'], reverse=True))
        if path == '/api/autopay': return self.send(200, self.autopay_state(acc))
        self.send(404, {'error': 'not_found'})

    def log_message(self, *a): pass


if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('db'); ap.add_argument('--port', type=int, default=8080)
    a = ap.parse_args()
    H.db = sqlite3.connect(a.db, check_same_thread=False); P.init(H.db); L.init(H.db); H.prov = P.provider()
    print(f'API на :{a.port}, оплата: {H.prov.name}'); ThreadingHTTPServer(('127.0.0.1', a.port), H).serve_forever()
