#!/usr/bin/env python3
"""
Реестр оплат из приложения в формате реестра ПСБ — для «Загрузки реестров» в 1С.

  python3 payments_registry.py app.db /opt/domofon-api/registry
        — по одному файлу на каждый прошедший день с новыми (ещё не выгруженными) оплатами;
          сегодняшние оплаты попадут в реестр завтра
  python3 payments_registry.py app.db /opt/domofon-api/registry --date 2026-10-22 --again
        — пересобрать реестр за день, включая уже выгруженные

Формат — тот, что разбирает модуль «ОплатаДомофона» в 1С (формат 7, «ПСБ»):
Windows-1251, разделитель «;», строки CRLF, имя файла обязательно на .CSV (заглавными)
  Дата платежа;Время платежа;ID операции;Лицевой счет;Сумма перевода;Сумма к возмещению;Сумма комиссии
  2026-10-22;17:57:01;900000000001;139430;2635.00;2635.00;0.00
  =1;2635.00;2635.00;0.00;;;
Дата — ГГГГ-ММ-ДД (1С берёт её из первых 10 символов именно в таком виде).
Итоговая строка начинается с «=»: 1С берёт из неё общую сумму реестра и не считает платежом.
--no-total — без итоговой строки.
Банк «ЮMoney» 1С ставит по слову YOOKASSA в имени файла (правка модуля, код банка 29).
Лицевой счёт — без ведущих нулей, как у ПСБ. Комиссию берём из ЮKassa (income_amount).
Имя файла: <префикс>_<ГГГГММДД>.CSV, префикс задаётся --prefix (по умолчанию по провайдеру:
YOOKASSA_PAY_<shopId>, ROBOKASSA_PAY_<магазин>, SBER_PAY_ONLINE; или REGISTRY_PREFIX в настройках).
"""
import os, sys, argparse, sqlite3, collections, datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import payments as P

HEAD = 'Дата платежа;Время платежа;ID операции;Лицевой счет;Сумма перевода;Сумма к возмещению;Сумма комиссии'


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('db'); ap.add_argument('out_dir')
    ap.add_argument('--date', help='ГГГГ-ММ-ДД — только этот день')
    ap.add_argument('--again', action='store_true', help='включить уже выгруженные')
    ap.add_argument('--no-total', action='store_true', help='не добавлять итоговую строку «=…»')
    ap.add_argument('--prefix', default=P.registry_prefix())
    a = ap.parse_args()
    os.makedirs(a.out_dir, exist_ok=True)
    db = sqlite3.connect(a.db); P.init(db)
    cols = [r[1] for r in db.execute('PRAGMA table_info(payments)')]
    if 'registry' not in cols: db.execute('ALTER TABLE payments ADD COLUMN registry TEXT')
    if 'income' not in cols: db.execute('ALTER TABLE payments ADD COLUMN income REAL')
    q = "SELECT rowid, id, account, amount, paid, provider_order, income FROM payments WHERE status='paid'"
    args = []
    if not a.again: q += ' AND registry IS NULL'
    if a.date: q += ' AND substr(paid,1,10)=?'; args.append(a.date)
    else:      q += ' AND substr(paid,1,10)<?'; args.append(datetime.date.today().isoformat())   # сегодняшний день ещё не закончился
    rows = db.execute(q + ' ORDER BY paid', args).fetchall()
    if not rows:
        print('новых оплат нет'); return
    prov = P.provider()
    days = collections.defaultdict(list)
    for rowid, pid, acc, amount, paid, order, income in rows:
        if income is None:                       # чистая сумма после комиссии — спрашиваем у провайдера один раз (если он её отдаёт)
            try: income = prov.get_payment(order).get('income') if order else None
            except Exception: income = None
            if income is None: income = amount
            db.execute('UPDATE payments SET income=? WHERE id=?', (income, pid))
        days[paid[:10]].append((rowid, pid, acc, amount, paid, income))
    for day, items in sorted(days.items()):
        y, m, d = day.split('-')
        name = os.path.join(a.out_dir, f'{a.prefix}_{y}{m}{d}.CSV')
        n = 2
        while os.path.exists(name) and not a.again:          # «опоздавшие» оплаты за уже выгруженный день — отдельным файлом
            name = os.path.join(a.out_dir, f'{a.prefix}_{y}{m}{d}_{n}.CSV'); n += 1
        lines = [HEAD]
        tot = net = 0.0
        for rowid, pid, acc, amount, paid, income in items:
            fee = round(amount - income, 2)
            lines.append(f'{y}-{m}-{d};{paid[11:19]};{900000000000 + rowid};{int(acc)};{amount:.2f};{income:.2f};{fee:.2f}')
            tot += amount; net += income
        if not a.no_total: lines.append(f'={len(items)};{tot:.2f};{net:.2f};{tot - net:.2f};;;')
        with open(name, 'w', encoding='cp1251', newline='') as f:
            f.write('\r\n'.join(lines) + '\r\n')
        db.executemany('UPDATE payments SET registry=? WHERE id=?', [(os.path.basename(name), it[1]) for it in items])
        print(f'{os.path.basename(name)}: {len(items)} оплат на {tot:.2f} ₽')
    db.commit()


if __name__ == '__main__':
    main()