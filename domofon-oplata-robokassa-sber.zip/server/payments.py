"""
Платежи и автоплатёж «Домофон Сервис».

Провайдер — переменная окружения PAY_PROVIDER (файл /etc/domofon-api.env на сервере):
  mock      — имитация, деньги не списываются (по умолчанию).
  yookassa  — ЮKassa, API v3 (https://api.yookassa.ru/v3). Нужны:
                YK_SHOP_ID     — shopId магазина (тестового или боевого)
                YK_SECRET_KEY  — секретный ключ (test_… для тестового магазина, live_… для боевого)
              Необязательно:
                YK_RECEIPT=1   — передавать чек по 54-ФЗ (если в ЮKassa подключены «Чеки от ЮKassa»).
                                 Чек уходит на телефон/e-mail, который абонент указал в приложении
                                 (таблица contacts). Без контакта платёж не создаётся.
                YK_VAT_CODE    — код НДС для чека (по умолчанию 1 = без НДС)
                YK_TAX_SYSTEM  — код системы налогообложения (1–6), если в ЮKassa их несколько;
                                 обычно не нужен
                YK_RECEIPT_EMAIL — запасной e-mail для чека, если абонент контакт не указал
                                 (например, автоплатёж, подключённый до появления поля)

Как устроено:
  * Оплата: создаём платёж с confirmation.type=redirect, абонент платит на странице ЮKassa
    (карта, СБП, SberPay, ЮMoney) и возвращается в приложение по return_url.
  * Автоплатёж: первый платёж (текущий долг или аванс за месяц) создаётся с save_payment_method=true —
    ЮKassa сохраняет карту и отдаёт payment_method.id. Дальше autopay_run.py раз в месяц
    создаёт платёж с payment_method_id без участия абонента.
  * Статус проверяем запросом GET /payments/{id}; уведомления ЮKassa (POST /api/yookassa/notify)
    только подсказывают «проверь этот платёж» — телу уведомления не доверяем.
Данные карт к нам не попадают.

Другие провайдеры (тот же интерфейс: create_payment / get_payment / charge_saved):

  robokassa — Робокасса (https://auth.robokassa.ru). Нужны:
                ROBO_LOGIN     — идентификатор магазина (MerchantLogin)
                ROBO_PASS1, ROBO_PASS2 — пароли №1 и №2 из технических настроек магазина
              Необязательно:
                ROBO_TEST=1    — тестовый режим (IsTest=1, тестовые пароли)
                ROBO_HASH      — алгоритм подписи, как в настройках магазина: md5 (по умолчанию), sha256
                ROBO_RECEIPT=1 — передавать чек (если подключены «Робочеки» или своя касса через Робокассу)
                ROBO_TAX       — система налогообложения для чека (usn_income, usn_income_outcome, osn …), по умолчанию usn_income
              В настройках магазина Робокассы:
                Result URL  = https://<сервер>/api/robokassa/result   (метод POST)
                Success URL = https://kueneej4-art.github.io/Domofon/app.html?paid=1   (метод GET)
                Fail URL    = https://kueneej4-art.github.io/Domofon/app.html?paid=0   (метод GET)
              Автоплатёж — «Периодические платежи» Робокассы (подключаются по заявке в поддержку Робокассы).

  sber      — Интернет-эквайринг Сбербанка (платёжный шлюз, REST API). Нужны:
                SBER_USER, SBER_PASSWORD — логин и пароль API-пользователя (обычно «…-api»)
              Необязательно:
                SBER_API_URL   — по умолчанию https://securepayments.sberbank.ru/payment/rest/
                                 (тестовый шлюз: https://ecomtest.sberbank.ru/payment/rest/)
                SBER_RECEIPT=1 — передавать корзину для чека (если у Сбера подключена онлайн-касса)
                SBER_TAX_SYSTEM — код системы налогообложения для чека (1 = УСН доход), по умолчанию 1
              Адрес для уведомлений (callback) в личном кабинете Сбера: https://<сервер>/api/sber/notify
              Автоплатёж — оплата по «связке» (bindingId); функцию включает банк по заявке.
"""
import os, json, time, uuid, base64, hashlib, urllib.request, urllib.error, urllib.parse
import xml.etree.ElementTree as ET


def env(name, default=''):
    """Значение настройки без пробелов и символов конца строки Windows (\r)."""
    return os.environ.get(name, default).strip().strip('"\'').strip()

SCHEMA = '''
CREATE TABLE IF NOT EXISTS autopay(account TEXT PRIMARY KEY, enabled INTEGER, day INTEGER, max_amount REAL,
    binding_id TEXT, card_mask TEXT, pending_order TEXT, updated TEXT);
CREATE TABLE IF NOT EXISTS payments(id TEXT PRIMARY KEY, account TEXT, amount REAL, kind TEXT, status TEXT,
    provider_order TEXT, created TEXT, paid TEXT, exported INTEGER DEFAULT 0);
CREATE INDEX IF NOT EXISTS pay_acc ON payments(account, status);
CREATE INDEX IF NOT EXISTS pay_ord ON payments(provider_order);
CREATE TABLE IF NOT EXISTS contacts(account TEXT PRIMARY KEY, receipt TEXT, updated TEXT);
'''
_DB = None          # база, открытая через init(): из неё берём контакт для чека, если его не передали явно


def init(db):
    global _DB
    db.executescript(SCHEMA)
    cols = [r[1] for r in db.execute('PRAGMA table_info(payments)')]       # колонки реестра для 1С
    if 'registry' not in cols: db.execute('ALTER TABLE payments ADD COLUMN registry TEXT')
    if 'income' not in cols: db.execute('ALTER TABLE payments ADD COLUMN income REAL')
    db.commit()
    _DB = db


# ---------- контакт для чека (54-ФЗ) ----------
def norm_contact(v):
    """'8 (912) 345-67-89' -> '79123456789'; e-mail -> в нижнем регистре; иначе ''."""
    v = str(v or '').strip()
    if not v: return ''
    if '@' in v:
        local, _, dom = v.rpartition('@')
        ok = local and '.' in dom and ' ' not in v and len(v) <= 64 and not dom.startswith('.') and not dom.endswith('.')
        return v.lower() if ok else ''
    d = ''.join(c for c in v if c.isdigit())
    if len(d) == 11 and d[0] in '78': return '7' + d[1:]
    if len(d) == 10 and d[0] == '9': return '7' + d
    return ''


def get_contact(db, account):
    db = db or _DB
    if db is None: return ''
    r = db.execute('SELECT receipt FROM contacts WHERE account=?', (account,)).fetchone()
    return r[0] if r and r[0] else ''


def set_contact(db, account, contact):
    db.execute('INSERT INTO contacts VALUES (?,?,?) ON CONFLICT(account) DO UPDATE SET receipt=excluded.receipt, updated=excluded.updated',
               (account, contact, now()))
    db.commit()


class NoContact(Exception):
    """Чеки включены, а телефона/e-mail для чека нет."""


def now(): return time.strftime('%Y-%m-%d %H:%M:%S')
def new_id(): return uuid.uuid4().hex[:16]


class Mock:
    """Имитация: всё проходит сразу, страницы оплаты нет (url=None)."""
    name = 'mock'

    receipt = False

    def create_payment(self, account, order_id, amount, return_url, save=False, description='', contact=None):
        return {'order': 'mock-' + order_id, 'url': None}

    def get_payment(self, order):
        return {'paid': True, 'final': True, 'method_id': 'mock-pm-' + order, 'card_mask': '•• 4242'}

    def charge_saved(self, account, order_id, amount, method_id, description='', contact=None):
        return {'ok': True, 'pending': False, 'order': 'mock-' + order_id}


class YooKassa:
    name = 'yookassa'
    URL = os.environ.get('YK_API_URL', 'https://api.yookassa.ru/v3/')   # подмена только для тестов

    def __init__(self):
        sid, key = env('YK_SHOP_ID'), env('YK_SECRET_KEY')
        if not sid or not key: raise RuntimeError('не заданы YK_SHOP_ID / YK_SECRET_KEY в /etc/domofon-api.env')
        self.auth = 'Basic ' + base64.b64encode(f'{sid}:{key}'.encode()).decode()
        self.receipt = env('YK_RECEIPT') == '1'
        self.vat = int(env('YK_VAT_CODE', '1') or 1)
        self.tax = env('YK_TAX_SYSTEM')
        self.test = key.startswith('test_')

    def call(self, method, path, body=None, idem=None):
        req = urllib.request.Request(self.URL + path, method=method,
                                     data=json.dumps(body).encode() if body is not None else None)
        req.add_header('Authorization', self.auth)
        req.add_header('Content-Type', 'application/json')
        if idem: req.add_header('Idempotence-Key', idem)
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            err = json.loads(e.read().decode() or '{}')
            raise RuntimeError(f"ЮKassa {e.code}: {err.get('code')} {err.get('description', '')}")

    def _body(self, account, order_id, amount, description, contact=None):
        b = {'amount': {'value': f'{amount:.2f}', 'currency': 'RUB'}, 'capture': True,
             'description': (description or f'Домофон, л/с {account}')[:128],
             'metadata': {'account': account, 'order_id': order_id}}
        if self.receipt:
            c = norm_contact(contact) or get_contact(None, account) or norm_contact(env('YK_RECEIPT_EMAIL'))
            if not c: raise NoContact(account)
            b['receipt'] = {'customer': {'email': c} if '@' in c else {'phone': c},
                            'items': [{'description': f'Обслуживание домофона, л/с {account}'[:128], 'quantity': '1.00',
                                       'amount': {'value': f'{amount:.2f}', 'currency': 'RUB'}, 'vat_code': self.vat,
                                       'payment_mode': 'full_payment', 'payment_subject': 'service'}]}
            if self.tax: b['receipt']['tax_system_code'] = int(self.tax)
        return b

    def create_payment(self, account, order_id, amount, return_url, save=False, description='', contact=None):
        b = self._body(account, order_id, amount, description, contact)
        b['confirmation'] = {'type': 'redirect', 'return_url': return_url}
        if save: b['save_payment_method'] = True
        r = self.call('POST', 'payments', b, idem=order_id)
        return {'order': r['id'], 'url': r['confirmation']['confirmation_url']}

    def get_payment(self, order):
        r = self.call('GET', 'payments/' + order)
        pm = r.get('payment_method') or {}
        card = pm.get('card') or {}
        mask = '•• ' + card['last4'] if card.get('last4') else {'sbp': 'СБП', 'yoo_money': 'ЮMoney', 'sberbank': 'SberPay'}.get(pm.get('type'), '')
        return {'paid': r['status'] == 'succeeded', 'final': r['status'] in ('succeeded', 'canceled'),
                'method_id': pm.get('id') if pm.get('saved') else None, 'card_mask': mask,
                'cancel_reason': (r.get('cancellation_details') or {}).get('reason'),
                'income': float((r.get('income_amount') or {}).get('value') or 0) or None}   # сумма за вычетом комиссии

    def charge_saved(self, account, order_id, amount, method_id, description='', contact=None):
        try:
            b = self._body(account, order_id, amount, description or f'Автоплатёж за домофон, л/с {account}', contact)
        except NoContact:
            return {'ok': False, 'pending': False, 'order': None, 'error': 'no_receipt_contact'}
        b['payment_method_id'] = method_id
        r = self.call('POST', 'payments', b, idem=order_id)
        if r['status'] == 'pending' and r.get('confirmation'):
            # банк требует подтверждения (3-D Secure) — без абонента не провести; платёж истечёт сам
            return {'ok': False, 'pending': False, 'order': r['id'], 'error': 'confirmation_required'}
        for _ in range(10):                                   # обычно ответ сразу succeeded/canceled
            if r['status'] in ('succeeded', 'canceled'): break
            time.sleep(3); r = self.call('GET', 'payments/' + r['id'])
        return {'ok': r['status'] == 'succeeded', 'pending': r['status'] not in ('succeeded', 'canceled'),
                'order': r['id'], 'error': (r.get('cancellation_details') or {}).get('reason')}


def _inv_id(order_id):
    """Номер счёта для Робокассы — целое число до 2^31 (наш order_id — 16 hex-символов)."""
    return str(int(order_id[:8], 16) % 2147483000 + 1)


def _xml_strip(root):
    for e in root.iter():
        if '}' in e.tag: e.tag = e.tag.split('}', 1)[1]
    return root


class Robokassa:
    name = 'robokassa'
    PAY_URL = 'https://auth.robokassa.ru/Merchant/Index.aspx'
    STATE_URL = 'https://auth.robokassa.ru/Merchant/WebService/Service.asmx/OpStateExt'
    RECUR_URL = 'https://auth.robokassa.ru/Merchant/Recurring'

    def __init__(self):
        self.login, self.p1, self.p2 = env('ROBO_LOGIN'), env('ROBO_PASS1'), env('ROBO_PASS2')
        if not (self.login and self.p1 and self.p2):
            raise RuntimeError('не заданы ROBO_LOGIN / ROBO_PASS1 / ROBO_PASS2 в /etc/domofon-api.env')
        self.test = env('ROBO_TEST') == '1'
        self.algo = (env('ROBO_HASH', 'md5') or 'md5').lower()
        self.receipt = env('ROBO_RECEIPT') == '1'
        self.tax = env('ROBO_TAX', 'usn_income') or 'usn_income'

    def sign(self, *parts):
        return hashlib.new(self.algo, ':'.join(str(p) for p in parts).encode()).hexdigest().upper()

    def check_result(self, out_sum, inv_id, signature):
        """Проверка подписи уведомления Result URL (пароль №2)."""
        return bool(signature) and self.sign(out_sum, inv_id, self.p2) == str(signature).upper()

    def _receipt(self, account, amount):
        if not self.receipt: return None
        r = {'sno': self.tax, 'items': [{'name': f'Обслуживание домофона, л/с {account}'[:128], 'quantity': 1,
             'sum': round(amount, 2), 'payment_method': 'full_payment', 'payment_object': 'service', 'tax': 'none'}]}
        return urllib.parse.quote(json.dumps(r, ensure_ascii=False, separators=(',', ':')))   # в подписи — закодированный один раз

    def create_payment(self, account, order_id, amount, return_url, save=False, description='', contact=None):
        inv, out = _inv_id(order_id), f'{amount:.2f}'
        rec = self._receipt(account, amount)
        q = {'MerchantLogin': self.login, 'OutSum': out, 'InvId': inv, 'Culture': 'ru', 'Encoding': 'utf-8',
             'Description': (description or f'Домофон, л/с {account}')[:100],
             'SignatureValue': self.sign(self.login, out, inv, *([rec] if rec else []), self.p1)}
        if rec: q['Receipt'] = rec                        # urlencode ниже закодирует ещё раз — так требует Робокасса для GET
        c = norm_contact(contact) or get_contact(None, account)
        if c and '@' in c: q['Email'] = c
        if save: q['Recurring'] = 'true'
        if self.test: q['IsTest'] = '1'
        return {'order': inv, 'url': self.PAY_URL + '?' + urllib.parse.urlencode(q)}

    def get_payment(self, order):
        q = urllib.parse.urlencode({'MerchantLogin': self.login, 'InvoiceID': order, 'Signature': self.sign(self.login, order, self.p2)})
        with urllib.request.urlopen(self.STATE_URL + '?' + q, timeout=30) as r:
            x = _xml_strip(ET.fromstring(r.read()))
        res = x.findtext('Result/Code')
        if res == '3':                                    # счёт ещё не создан (абонент не дошёл до оплаты)
            return {'paid': False, 'final': False, 'method_id': None, 'card_mask': ''}
        if res != '0':
            raise RuntimeError(f"Робокасса OpStateExt: код {res} {x.findtext('Result/Description') or ''}")
        st = x.findtext('State/Code')
        acc_mask = (x.findtext('Info/IncAccount') or '').strip()
        mask = '•• ' + acc_mask[-4:] if acc_mask[-4:].isdigit() else ''
        return {'paid': st == '100', 'final': st in ('100', '10', '60'),
                'method_id': order if st == '100' else None,          # для автоплатежа «связка» = номер первого счёта
                'card_mask': mask or 'карта', 'cancel_reason': None if st == '100' else st, 'income': None}

    def charge_saved(self, account, order_id, amount, method_id, description='', contact=None):
        inv, out = _inv_id(order_id), f'{amount:.2f}'
        rec = self._receipt(account, amount)
        f = {'MerchantLogin': self.login, 'InvoiceID': inv, 'PreviousInvoiceID': method_id, 'OutSum': out,
             'Description': (description or f'Автоплатёж за домофон, л/с {account}')[:100],
             'SignatureValue': self.sign(self.login, out, inv, *([rec] if rec else []), self.p1)}
        if rec: f['Receipt'] = rec                          # как и в ссылке оплаты: значение закодировано заранее
        req = urllib.request.Request(self.RECUR_URL, data=urllib.parse.urlencode(f).encode(), method='POST')
        with urllib.request.urlopen(req, timeout=60) as r:
            txt = r.read().decode('utf-8', 'replace').strip()
        if not txt.upper().startswith('OK'):
            return {'ok': False, 'pending': False, 'order': inv, 'error': txt[:120] or 'rejected'}
        # Робокасса приняла запрос; результат придёт на Result URL (там и отметим оплату)
        return {'ok': False, 'pending': True, 'order': inv}


class Sber:
    name = 'sber'

    def __init__(self):
        self.user, self.pwd = env('SBER_USER'), env('SBER_PASSWORD')
        if not (self.user and self.pwd): raise RuntimeError('не заданы SBER_USER / SBER_PASSWORD в /etc/domofon-api.env')
        self.url = env('SBER_API_URL', 'https://securepayments.sberbank.ru/payment/rest/') or 'https://securepayments.sberbank.ru/payment/rest/'
        if not self.url.endswith('/'): self.url += '/'
        self.receipt = env('SBER_RECEIPT') == '1'
        self.tax = env('SBER_TAX_SYSTEM', '1') or '1'
        self.test = 'ecomtest' in self.url or '3dsec' in self.url

    def call(self, method, **params):
        params.update(userName=self.user, password=self.pwd)
        req = urllib.request.Request(self.url + method, data=urllib.parse.urlencode(params).encode(), method='POST')
        req.add_header('Content-Type', 'application/x-www-form-urlencoded')
        with urllib.request.urlopen(req, timeout=40) as r:
            d = json.loads(r.read().decode() or '{}')
        if str(d.get('errorCode', '0')) not in ('0', ''):
            raise RuntimeError(f"Сбер {method}: {d.get('errorCode')} {d.get('errorMessage', '')}")
        return d

    def _register(self, account, order_id, amount, return_url, description, contact, extra):
        p = {'orderNumber': order_id, 'amount': int(round(amount * 100)), 'currency': '643', 'language': 'ru',
             'returnUrl': return_url, 'failUrl': return_url, 'description': (description or f'Домофон, л/с {account}')[:99],
             'jsonParams': json.dumps({'account': account}), **extra}
        if self.receipt:
            c = norm_contact(contact) or get_contact(None, account)
            if not c: raise NoContact(account)
            kop = int(round(amount * 100))
            p['taxSystem'] = self.tax
            p['orderBundle'] = json.dumps({'customerDetails': {'email': c} if '@' in c else {'phone': '+' + c},
                'cartItems': {'items': [{'positionId': '1', 'name': f'Обслуживание домофона, л/с {account}'[:100],
                    'quantity': {'value': 1, 'measure': 'шт'}, 'itemAmount': kop, 'itemPrice': kop, 'itemCode': 'domofon',
                    'tax': {'taxType': 0}, 'itemAttributes': {'attributes': [{'name': 'paymentMethod', 'value': '1'},
                                                                           {'name': 'paymentObject', 'value': '4'}]}}]}},
                ensure_ascii=False)
        return self.call('register.do', **p)

    def create_payment(self, account, order_id, amount, return_url, save=False, description='', contact=None):
        extra = {'clientId': account} if save else {}
        r = self._register(account, order_id, amount, return_url, description, contact, extra)
        return {'order': r['orderId'], 'url': r['formUrl']}

    def get_payment(self, order):
        r = self.call('getOrderStatusExtended.do', orderId=order)
        st = int(r.get('orderStatus', -1))
        pan = ((r.get('cardAuthInfo') or {}).get('maskedPan') or (r.get('cardAuthInfo') or {}).get('pan') or '')
        mask = '•• ' + pan[-4:] if pan[-4:].isdigit() else ('СБП' if 'SBP' in json.dumps(r) else '')
        return {'paid': st == 2, 'final': st in (2, 3, 4, 6),
                'method_id': (r.get('bindingInfo') or {}).get('bindingId'),
                'card_mask': mask, 'cancel_reason': r.get('actionCodeDescription'), 'income': None}

    def charge_saved(self, account, order_id, amount, method_id, description='', contact=None):
        try:
            r = self._register(account, order_id, amount, 'https://kueneej4-art.github.io/Domofon/app.html',
                               description or f'Автоплатёж за домофон, л/с {account}', contact,
                               {'clientId': account, 'features': 'AUTO_PAYMENT'})
        except NoContact:
            return {'ok': False, 'pending': False, 'order': None, 'error': 'no_receipt_contact'}
        order = r['orderId']
        try:
            self.call('paymentOrderBinding.do', mdOrder=order, bindingId=method_id)
        except RuntimeError as e:
            return {'ok': False, 'pending': False, 'order': order, 'error': str(e)[:120]}
        s = self.get_payment(order)
        return {'ok': s['paid'], 'pending': not s['final'], 'order': order, 'error': s.get('cancel_reason')}


def provider():
    p = env('PAY_PROVIDER').lower()
    return {'yookassa': YooKassa, 'robokassa': Robokassa, 'sber': Sber}.get(p, Mock)()


def registry_prefix(prov=None):
    """Префикс имени файла реестра оплат из приложения для 1С (по провайдеру)."""
    import re as _re
    if env('REGISTRY_PREFIX'): return _re.sub(r'[^A-Za-z0-9_]', '_', env('REGISTRY_PREFIX'))
    name = (prov.name if prov else env('PAY_PROVIDER').lower()) or 'mock'
    return _re.sub(r'[^A-Za-z0-9_]', '_', {'yookassa': 'YOOKASSA_PAY_' + (env('YK_SHOP_ID') or 'TEST'),
            'robokassa': 'ROBOKASSA_PAY_' + (env('ROBO_LOGIN') or 'TEST'),
            'sber': 'SBER_PAY_ONLINE'}.get(name, 'YOOKASSA_PAY_TEST'))


def unexported_paid(db, account):
    """Оплаты из приложения, которых ещё нет в выгрузке 1С, — вычитаем из долга."""
    built = db.execute("SELECT value FROM meta WHERE key='built'").fetchone()
    since = built[0].replace('T', ' ') if built else '1970-01-01'
    r = db.execute("SELECT coalesce(sum(amount),0) FROM payments WHERE account=? AND status='paid' AND paid>?",
                   (account, since)).fetchone()
    return r[0]
